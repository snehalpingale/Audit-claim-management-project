export class User{
    public username : string = "";
    public logStatus : boolean = false;

    constructor(

    ){}
}