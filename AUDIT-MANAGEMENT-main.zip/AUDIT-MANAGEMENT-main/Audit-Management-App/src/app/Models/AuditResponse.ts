export interface AuditResponse {
    auditId: number;
    managerName: string;
    projectExecutionStatus: string;
    projectName: string;
    remedialActionDuration: string;
}