INSERT INTO project_manager(id, name, username, password, project_name) VALUES (1, 'Nikunj Baid', 'nikunj', 'nikunj12', 'Project-1');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (2, 'Chandu Reddy', 'chandu', 'chandu12', 'Project-2');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (3, 'Navya Chowdary', 'navya', 'navya12', 'Project-3');

